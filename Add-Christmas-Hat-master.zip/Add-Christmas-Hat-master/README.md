# Add-Christmas-Hat

#### Add Christmas hat on one's head based on OpneCV and Dlib
#### You can download a trained facial shape predictor from [http://dlib.net/files/shape_predictor_5_face_landmarks.dat.bz2](http://dlib.net/files/shape_predictor_5_face_landmarks.dat.bz2)
---

<div>
<img src="https://github.com/LiuXiaolong19920720/Add-Christmas-Hat/blob/master/output.jpg" width="70%">
</div>

---
